// utilities.js
export function greet(name : string) {
    return `Hello, ${name}!`;
  }
  
  export function addNumbers(a : number, b: number) {
    return a + b;
  }
  