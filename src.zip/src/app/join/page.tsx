import { ShowRoom } from "@/typings"
// import { useState } from "react";

function joinPage() {
    // const [showRoom, setShowRoom] = useState<ShowRoom | null>(null);

}
export default joinPage;