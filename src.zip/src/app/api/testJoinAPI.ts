import { NextApiRequest, NextApiResponse } from 'next';

import { ShowRoom } from "@/typings"
export const testData: ShowRoom[] = [{
    roomName: "Mek",
    roomID: "01",
    NumberPlayers: 9,
    currentPlayes:8,
    time:8,
    privateStatus:false,
},{
    roomName: "Mek02",
    roomID: "02",
    NumberPlayers: 4,
    currentPlayes:3,
    time:3,
    privateStatus:true,
}]

export default function handler(req: NextApiRequest, res: NextApiResponse) {
    res.status(200).json(testData);
  }