/** @type {import('next').NextConfig} */
const nextConfig = {
    images: {
        domains: ['cf.geekdo-images.com'],
      },
};

export default nextConfig;
