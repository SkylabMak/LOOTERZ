export const lobbys = [
    {
        lobbyId : 1,
        ownerName : "Kemkai",
        usersInRoom : ["Kemkai", "Mickkie2K", "Garaii", "Mek", "kem" ],
        currentPlayer : 5,
        maxPlayer : 6,
        time : 6
    },
    {
        lobbyId: 2,
        ownerName : "Mickie",
        usersInRoom : ["Kemkai", "Mickkie2K", "Garaii", "Mek", "kem", "kem" ],
        currentPlayer : 6,
        maxPlayer : 6,
        time : 2,
    },
    {
        lobbyId: 3,
        ownerName : "Mek",
        usersInRoom : ["Kemkai", "Mickkie2K", "Garaii", "Mek" ],
        currentPlayer : 4,
        maxPlayer : 7,
        time : 3,
    },
];