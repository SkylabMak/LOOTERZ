export interface ShowRoom {
    roomName: string;
    roomID: string;
    NumberPlayers:number;
    currentPlayes:number;
    time:number;
    privateStatus:boolean;
  }